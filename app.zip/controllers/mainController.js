
app.controller("mainController",function($scope,$rootScope,$location){


/*
  $rootScope.isFranch = "true";
$scope.setLang = function(){
  var url = $location.path();
  if(url.indexOf("/ar")){
      $rootScope.isFranch = "false";
  }else {
      $rootScope.isFranch = "true";
  }

}
*/


});
