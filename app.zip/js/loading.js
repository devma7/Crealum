
$(window).on("load",function(){
  $('.loading').hide();
});
